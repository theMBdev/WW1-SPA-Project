const http = require('http')
const port = 3000
var value = 10

const requestHandler = (request, response) => {
  console.log(request.url)
  response.end("Value is " + value)
}

const server = http.createServer(requestHandler)

server.listen(port, (err) => {
  if (err) {
    return console.log('something bad happened', err)
  }

  console.log(`server is listening on ${port}`)
})

setInterval(function(){ 
  value = value + 10; 
  console.log("new value - " + value)
}, 12000);